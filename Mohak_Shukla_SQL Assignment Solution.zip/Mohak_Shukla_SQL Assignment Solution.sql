USE master;
GO

--Question 1 : Database And Sample questions
-- Clean up existing tables in reverse-dependency order
IF OBJECT_ID('dbo.ExecutionLog', 'U') IS NOT NULL DROP TABLE dbo.ExecutionLog;
IF OBJECT_ID('dbo.SessionLog', 'U') IS NOT NULL DROP TABLE dbo.SessionLog;
IF OBJECT_ID('dbo.EmployeeProjects', 'U') IS NOT NULL DROP TABLE dbo.EmployeeProjects;
IF OBJECT_ID('dbo.Projects', 'U') IS NOT NULL DROP TABLE dbo.Projects;
IF OBJECT_ID('dbo.Employees', 'U') IS NOT NULL DROP TABLE dbo.Employees;
IF OBJECT_ID('dbo.Departments', 'U') IS NOT NULL DROP TABLE dbo.Departments;
IF OBJECT_ID('dbo.usp_AddSurrogateKey', 'P') IS NOT NULL DROP PROCEDURE dbo.usp_AddSurrogateKey;
GO

-- 1. Departments Table
CREATE TABLE dbo.Departments (
    DepartmentId INT IDENTITY(1,1) NOT NULL,
    DepartmentName NVARCHAR(100) NOT NULL,
    CONSTRAINT PK_Departments PRIMARY KEY (DepartmentId)
);

-- 2. Employees Table
CREATE TABLE dbo.Employees (
    EmployeeId INT IDENTITY(1,1) NOT NULL,
    EmployeeName NVARCHAR(100) NOT NULL,
    DepartmentId INT NOT NULL,
    Salary DECIMAL(12, 2) NOT NULL,
    CONSTRAINT PK_Employees PRIMARY KEY (EmployeeId),
    CONSTRAINT FK_Employees_Departments FOREIGN KEY (DepartmentId) 
        REFERENCES dbo.Departments(DepartmentId)
);

-- 3. Projects Table
CREATE TABLE dbo.Projects (
    ProjectId INT IDENTITY(1,1) NOT NULL,
    ProjectName NVARCHAR(100) NOT NULL,
    DepartmentId INT NOT NULL,
    CONSTRAINT PK_Projects PRIMARY KEY (ProjectId),
    CONSTRAINT FK_Projects_Departments FOREIGN KEY (DepartmentId) 
        REFERENCES dbo.Departments(DepartmentId)
);

-- 4. EmployeeProjects Table
CREATE TABLE dbo.EmployeeProjects (
    EmployeeId INT NOT NULL,
    ProjectId INT NOT NULL,
    HoursWorked DECIMAL(6,2) NOT NULL,
    CONSTRAINT PK_EmployeeProjects PRIMARY KEY (EmployeeId, ProjectId),
    CONSTRAINT FK_EmployeeProjects_Employees FOREIGN KEY (EmployeeId) 
        REFERENCES dbo.Employees(EmployeeId),
    CONSTRAINT FK_EmployeeProjects_Projects FOREIGN KEY (ProjectId) 
        REFERENCES dbo.Projects(ProjectId)
);
GO

-- Seed Data
INSERT INTO dbo.Departments (DepartmentName) VALUES 
    (N'Engineering'), (N'Data Analytics'), (N'Product Management');

INSERT INTO dbo.Employees (EmployeeName, DepartmentId, Salary) VALUES 
    (N'Grace Van Pelt', 1, 95000.00),
    (N'Patrick Jane', 1, 105000.00),
    (N'Kimball Cho', 2, 88000.00),
    (N'Thom Yorke', 2, 92000.00),
    (N'Wayne Rigsby', 3, 75000.00),
    (N'Ryan Gosling', 3, 81000.00);

INSERT INTO dbo.Projects (ProjectName, DepartmentId) VALUES 
    (N'Cloud Migration', 1),
    (N'Data Warehouse v2', 2),
    (N'Mobile App Redesign', 1),
    (N'Market Research', 3);

INSERT INTO dbo.EmployeeProjects (EmployeeId, ProjectId, HoursWorked) VALUES 
    (1, 1, 65.00),
    (2, 1, 55.00),
    (3, 2, 45.00),
    (4, 2, 40.00),
    (1, 3, 30.00),
    (5, 4, 25.00),
    (6, 4, 35.00),
    (2, 3, 20.00);
GO

--Question 2 : Multi-table CTE Report

WITH DepartmentProjectSummary AS (
    SELECT 
        d.DepartmentName,
        p.ProjectName,
        COUNT(DISTINCT ep.EmployeeId) AS TotalEmployees,
        SUM(ep.HoursWorked) AS TotalHours,
        ROUND(AVG(e.Salary), 2) AS AverageSalary
    FROM dbo.Departments d
    INNER JOIN dbo.Projects p ON d.DepartmentId = p.DepartmentId
    INNER JOIN dbo.EmployeeProjects ep ON p.ProjectId = ep.ProjectId
    INNER JOIN dbo.Employees e ON ep.EmployeeId = e.EmployeeId
    GROUP BY d.DepartmentName, p.ProjectName
)
SELECT 
    DepartmentName,
    ProjectName,
    TotalEmployees,
    TotalHours,
    AverageSalary
FROM DepartmentProjectSummary
WHERE TotalHours > 100 
  AND TotalEmployees >= 2
ORDER BY TotalHours DESC;
GO

--Question 3 : Logging Tables
CREATE TABLE dbo.SessionLog (
    SessionLogId INT IDENTITY(1,1) NOT NULL,
    SessionId INT NOT NULL DEFAULT @@SPID,
    UserName NVARCHAR(128) NOT NULL,
    SessionStartTime DATETIME2(7) NOT NULL,
    SessionEndTime DATETIME2(7) NULL,
    SessionStatus NVARCHAR(20) NOT NULL,
    FinalMessage NVARCHAR(MAX) NULL,
    CONSTRAINT PK_SessionLog PRIMARY KEY (SessionLogId),
    CONSTRAINT CHK_SessionStatus CHECK (SessionStatus IN (N'Running', N'Completed', N'Skipped', N'Failed'))
);

CREATE TABLE dbo.ExecutionLog (
    ExecutionLogId INT IDENTITY(1,1) NOT NULL,
    SessionLogId INT NOT NULL,
    ProcedureName NVARCHAR(128) NOT NULL,
    TableName NVARCHAR(128) NOT NULL,
    OperationName NVARCHAR(100) NOT NULL,
    ExecutionStartTime DATETIME2(7) NOT NULL,
    ExecutionEndTime DATETIME2(7) NULL,
    ExecutionStatus NVARCHAR(20) NOT NULL,
    RowsAffected INT NULL,
    ErrorNumber INT NULL,
    ErrorMessage NVARCHAR(MAX) NULL,
    CONSTRAINT PK_ExecutionLog PRIMARY KEY (ExecutionLogId),
    CONSTRAINT FK_ExecutionLog_SessionLog FOREIGN KEY (SessionLogId) 
        REFERENCES dbo.SessionLog(SessionLogId),
    CONSTRAINT CHK_ExecutionStatus CHECK (ExecutionStatus IN (N'Running', N'Completed', N'Skipped', N'Failed'))
);
GO

--Question 4 & 5 : Stored Procedure

CREATE PROCEDURE dbo.usp_AddSurrogateKey
    @TableName SYSNAME
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @SessionLogId INT,
            @ExecutionLogId INT,
            @StartTime DATETIME2(7) = SYSDATETIME(),
            @EndTime DATETIME2(7),
            @CurrentUser NVARCHAR(128) = SUSER_SNAME(),
            @RowCount INT = 0,
            @SqlStatement NVARCHAR(MAX),
            @HasPrimaryKey BIT = 0,
            @TargetTableObj INT;

 -- Step 1: Initialize Session Log
    INSERT INTO dbo.SessionLog (SessionId, UserName, SessionStartTime, SessionStatus, FinalMessage)
    VALUES (@@SPID, @CurrentUser, @StartTime, N'Running', N'Procedure execution initiated.');
    SET @SessionLogId = SCOPE_IDENTITY();

 -- Step 2: Initialize Execution Log
    INSERT INTO dbo.ExecutionLog (
        SessionLogId, ProcedureName, TableName, OperationName, ExecutionStartTime, ExecutionStatus
    )
    VALUES (
        @SessionLogId, OBJECT_NAME(@@PROCID), ISNULL(@TableName, N'UNKNOWN'), N'AddSurrogateKey', @StartTime, N'Running'
    );
    SET @ExecutionLogId = SCOPE_IDENTITY();

    BEGIN TRY
  -- Validate Table Existence
        SET @TargetTableObj = OBJECT_ID(QUOTENAME(N'dbo') + N'.' + QUOTENAME(@TableName), 'U');
        
        IF @TargetTableObj IS NULL
        BEGIN
            DECLARE @NoTableMsg NVARCHAR(255) = N'Validation Failed: Table dbo.' + QUOTENAME(ISNULL(@TableName, '')) + N' does not exist.';
            SET @EndTime = SYSDATETIME();
            
            UPDATE dbo.ExecutionLog 
            SET ExecutionEndTime = @EndTime, ExecutionStatus = N'Skipped', ErrorMessage = @NoTableMsg 
            WHERE ExecutionLogId = @ExecutionLogId;

            UPDATE dbo.SessionLog 
            SET SessionEndTime = @EndTime, SessionStatus = N'Skipped', FinalMessage = @NoTableMsg 
            WHERE SessionLogId = @SessionLogId;

            PRINT @NoTableMsg;
            RETURN;
        END

   -- Validate if SurrogateKey Column Already Exists
        IF EXISTS (
            SELECT 1 FROM sys.columns 
            WHERE object_id = @TargetTableObj AND name = N'SurrogateKey'
        )
        BEGIN
            DECLARE @ExistsMsg NVARCHAR(255) = N'Skipped: Column [SurrogateKey] already exists in dbo.' + QUOTENAME(@TableName) + N'.';
            SET @EndTime = SYSDATETIME();

            UPDATE dbo.ExecutionLog 
            SET ExecutionEndTime = @EndTime, ExecutionStatus = N'Skipped', ErrorMessage = @ExistsMsg 
            WHERE ExecutionLogId = @ExecutionLogId;

            UPDATE dbo.SessionLog 
            SET SessionEndTime = @EndTime, SessionStatus = N'Skipped', FinalMessage = @ExistsMsg 
            WHERE SessionLogId = @SessionLogId;

            PRINT @ExistsMsg;
            RETURN;
        END

   -- Count existing rows affected
        SET @SqlStatement = N'SELECT @cnt = COUNT(*) FROM dbo.' + QUOTENAME(@TableName);
        EXEC sp_executesql @SqlStatement, N'@cnt INT OUTPUT', @cnt = @RowCount OUTPUT;

   -- Check if target table already has a Primary Key
        IF EXISTS (
            SELECT 1 FROM sys.key_constraints 
            WHERE parent_object_id = @TargetTableObj AND type = 'PK'
        )
            SET @HasPrimaryKey = 1;

   -- Begin Transaction for DDL Alteration
        BEGIN TRANSACTION;

   -- Add SurrogateKey Identity Column
        SET @SqlStatement = N'ALTER TABLE dbo.' + QUOTENAME(@TableName) + N' ADD SurrogateKey BIGINT IDENTITY(1,1) NOT NULL;';
        EXEC sp_executesql @SqlStatement;

    -- Add Constraint
        IF @HasPrimaryKey = 0
        BEGIN
            SET @SqlStatement = N'ALTER TABLE dbo.' + QUOTENAME(@TableName) + 
                                N' ADD CONSTRAINT ' + QUOTENAME(N'PK_' + @TableName + N'_SurrogateKey') + 
                                N' PRIMARY KEY (SurrogateKey);';
        END
        ELSE
        BEGIN
            SET @SqlStatement = N'ALTER TABLE dbo.' + QUOTENAME(@TableName) + 
                                N' ADD CONSTRAINT ' + QUOTENAME(N'UQ_' + @TableName + N'_SurrogateKey') + 
                                N' UNIQUE (SurrogateKey);';
        END
        EXEC sp_executesql @SqlStatement;

        COMMIT TRANSACTION;

   -- Step 3: Log Successful Completion
        SET @EndTime = SYSDATETIME();
        DECLARE @SuccessMsg NVARCHAR(255) = N'Success: SurrogateKey added to dbo.' + QUOTENAME(@TableName) + N' successfully.';

        UPDATE dbo.ExecutionLog 
        SET ExecutionEndTime = @EndTime, ExecutionStatus = N'Completed', RowsAffected = @RowCount 
        WHERE ExecutionLogId = @ExecutionLogId;

        UPDATE dbo.SessionLog 
        SET SessionEndTime = @EndTime, SessionStatus = N'Completed', FinalMessage = @SuccessMsg 
        WHERE SessionLogId = @SessionLogId;

        PRINT @SuccessMsg;

    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        SET @EndTime = SYSDATETIME();
        DECLARE @ErrNum INT = ERROR_NUMBER();
        DECLARE @ErrMsg NVARCHAR(MAX) = ERROR_MESSAGE();

        UPDATE dbo.ExecutionLog 
        SET ExecutionEndTime = @EndTime, ExecutionStatus = N'Failed', ErrorNumber = @ErrNum, ErrorMessage = @ErrMsg 
        WHERE ExecutionLogId = @ExecutionLogId;

        UPDATE dbo.SessionLog 
        SET SessionEndTime = @EndTime, SessionStatus = N'Failed', FinalMessage = N'Error occurred: ' + @ErrMsg 
        WHERE SessionLogId = @SessionLogId;

        THROW;
    END CATCH
END;
GO

  -- QUESTION 6: Test and Verification Scenarios

  -- Scenario 1: Successful First Execution
EXEC dbo.usp_AddSurrogateKey @TableName = N'EmployeeProjects';
GO

-- Scenario 2: Repeated Execution (Skipped)
EXEC dbo.usp_AddSurrogateKey @TableName = N'EmployeeProjects';
GO

-- Scenario 3: Non-Existent Table Execution (Skipped)
EXEC dbo.usp_AddSurrogateKey @TableName = N'UnknownTable';
GO

-- Verify Logs
SELECT 
    s.SessionLogId,
    s.SessionId,
    s.UserName,
    s.SessionStatus,
    s.SessionStartTime,
    s.SessionEndTime,
    s.FinalMessage,
    e.ExecutionLogId,
    e.TableName,
    e.ExecutionStatus,
    e.RowsAffected,
    e.ErrorMessage
FROM dbo.SessionLog s
INNER JOIN dbo.ExecutionLog e ON s.SessionLogId = e.SessionLogId
ORDER BY s.SessionLogId ASC;
GO

-- Verify Updated Table
EXEC sp_executesql N'
    SELECT EmployeeId, ProjectId, HoursWorked, SurrogateKey 
    FROM dbo.EmployeeProjects;
';
GO